﻿using Model.BookDSTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class BookDAO : IBookDAO
    {

        public List<Book> getPublisherYear(int PublishYear)
        {
            ViewBookTableAdapter objViewBookTableAdapter = new ViewBookTableAdapter();
            BookDS.ViewBookDataTable objTabBookDataTable = objViewBookTableAdapter.GetDataByPublishYear(PublishYear);

            int dataCount = objTabBookDataTable.Count();
            if (dataCount == 0)
            {
                return null;
            }
            else
            {
                List<Book> allBook = new List<Book>();
                foreach (DataRow row in objTabBookDataTable.Rows)
                {
                    Book objBook = new Book();
                    objBook.Author1 = Convert.ToInt32(row["Author"].ToString());
                    objBook.ISBN1 = row["ISBN"].ToString();
                    objBook.BookName1 = row["BookName"].ToString();
                    objBook.Publisher1 = row["Publisher"].ToString();
                    objBook.PublishYear1 = Convert.ToInt32(row["PublishYear"].ToString());
                    objBook.Pages1 = Convert.ToInt32(row["Pages"].ToString());
                    objBook.AuthorName1 = row["AuthorName"].ToString();
                    objBook.CategoryName1 = row["CategoryName"].ToString();
                    objBook.Category1 = Convert.ToInt32(row["Category"].ToString());
                    objBook.LanguageName1 = row["LanguageName"].ToString();
                    objBook.Language1 = Convert.ToInt32(row["Language"].ToString());

                    allBook.Add(objBook);

                }
                return allBook;

             
            }
        }

        public List<Book> getAllBook()
        {
            ViewBookTableAdapter objViewBookTableAdapter = new ViewBookTableAdapter();
            BookDS.ViewBookDataTable objTabBookDataTable = objViewBookTableAdapter.GetData();

            int dataCount = objTabBookDataTable.Count();
            if (dataCount == 0)
            {
                return null;
            }
            else
            {
                List<Book> allBook = new List<Book>();
                foreach (DataRow row in objTabBookDataTable.Rows)
                {
                    Book objBook = new Book();
                    objBook.Author1 = Convert.ToInt32(row["Author"].ToString());
                    objBook.ISBN1 = row["ISBN"].ToString();
                    objBook.BookName1 = row["BookName"].ToString();
                    objBook.Publisher1 = row["Publisher"].ToString();
                    objBook.PublishYear1 = Convert.ToInt32(row["PublishYear"].ToString());
                    objBook.Pages1 = Convert.ToInt32(row["Pages"].ToString());
                    objBook.AuthorName1 = row["AuthorName"].ToString();
                    objBook.CategoryName1 = row["CategoryName"].ToString();
                    objBook.Category1 = Convert.ToInt32(row["Category"].ToString());
                    objBook.LanguageName1 = row["LanguageName"].ToString();
                    objBook.Language1 = Convert.ToInt32(row["Language"].ToString());

                    allBook.Add(objBook);

                }
                return allBook;
            }


        }

        public List<Book> getAuthor(int Author)
        {
            ViewBookTableAdapter objViewBookTableAdapter = new ViewBookTableAdapter();
            BookDS.ViewBookDataTable objTabBookDataTable = objViewBookTableAdapter.GetDataByAuthor(Author);

            int dataCount = objTabBookDataTable.Count();
            if (dataCount == 0)
            {
                return null;
            }
            else
            {
                List<Book> allBook = new List<Book>();
                foreach (DataRow row in objTabBookDataTable.Rows)
                {
                    Book objBook = new Book();
                    objBook.Author1 = Convert.ToInt32(row["Author"].ToString());
                    objBook.ISBN1 = row["ISBN"].ToString();
                    objBook.BookName1 = row["BookName"].ToString();
                    objBook.Publisher1 = row["Publisher"].ToString();
                    objBook.PublishYear1 = Convert.ToInt32(row["PublishYear"].ToString());
                    objBook.Pages1 = Convert.ToInt32(row["Pages"].ToString());
                    objBook.AuthorName1 = row["AuthorName"].ToString();
                    objBook.CategoryName1 = row["CategoryName"].ToString();
                    objBook.Category1 = Convert.ToInt32(row["Category"].ToString());
                    objBook.LanguageName1 = row["LanguageName"].ToString();
                    objBook.Language1 = Convert.ToInt32(row["Language"].ToString());

                    allBook.Add(objBook);

                }
                return allBook;


            }
        }

        public List<Book> getTitle(String Title)
        {
            ViewBookTableAdapter objViewBookTableAdapter = new ViewBookTableAdapter();
            BookDS.ViewBookDataTable objTabBookDataTable = objViewBookTableAdapter.GetDataByTitle(Title);

            int dataCount = objTabBookDataTable.Count();
            if (dataCount == 0)
            {
                return null;
            }
            else
            {
                List<Book> allBook = new List<Book>();
                foreach (DataRow row in objTabBookDataTable.Rows)
                {
                    Book objBook = new Book();
                    objBook.Author1 = Convert.ToInt32(row["Author"].ToString());
                    objBook.ISBN1 = row["ISBN"].ToString();
                    objBook.BookName1 = row["BookName"].ToString();
                    objBook.Publisher1 = row["Publisher"].ToString();
                    objBook.PublishYear1 = Convert.ToInt32(row["PublishYear"].ToString());
                    objBook.Pages1 = Convert.ToInt32(row["Pages"].ToString());
                    objBook.AuthorName1 = row["AuthorName"].ToString();
                    objBook.CategoryName1 = row["CategoryName"].ToString();
                    objBook.Category1 = Convert.ToInt32(row["Category"].ToString());
                    objBook.LanguageName1 = row["LanguageName"].ToString();
                    objBook.Language1 = Convert.ToInt32(row["Language"].ToString());
                    allBook.Add(objBook);
                }
                return allBook;
            }
        }


        public void addAuthor(String authorName)
        {
            TabAuthorTableAdapter objTabAuthorAdapter = new TabAuthorTableAdapter();
            objTabAuthorAdapter.AddAuthor(authorName);
        }

        public void addCategory(String catName) {
            TabCategoryTableAdapter objTabCatAdapter = new TabCategoryTableAdapter();
            objTabCatAdapter.AddCategory(catName);
        }

        public void addLanguage(String languageName) {
            TabLanguageTableAdapter objTabLangAdapt = new TabLanguageTableAdapter();
            objTabLangAdapt.addLanguage(languageName);
        }

        public void addNewBook(String ISBN, String BookName, int Author, int Category, int Language, int PublishYear, int Pages, String Publisher) {
            TabBookTableAdapter objTabBookAdapter = new TabBookTableAdapter();
            objTabBookAdapter.insertNewBook(ISBN, BookName, Author, Category, Language, PublishYear, Pages, Publisher);

        }

        public void updateBook(String ISBN, String BookName, int Author, int Category, int Language, int PublishYear, int Pages, String Publisher,String refISBN) {
            TabBookTableAdapter objTabBookAdapter = new TabBookTableAdapter();
            objTabBookAdapter.updateBook(ISBN, BookName, Author, Category, Language, PublishYear, Pages, Publisher,refISBN);       
        }

        public void delete(String ISBN) {
            TabBookTableAdapter objTabBookAdapter = new TabBookTableAdapter();
            objTabBookAdapter.deleteBook(ISBN);
        }

        public void addBookReservation(String ISBN, int UID,String reserveDate) {
            TabReservedTableAdapter objTabResAdapter = new TabReservedTableAdapter();
            objTabResAdapter.AddReservation(UID, ISBN, reserveDate);
        
        }

        public List<Book> getAllBookAvailable()
        {
            ViewBookAvailableTableAdapter objViewBookTableAvailableAdapter = new ViewBookAvailableTableAdapter();
            BookDS.ViewBookAvailableDataTable objViewBookAvailable = objViewBookTableAvailableAdapter.GetData();

            int dataCount = objViewBookAvailable.Count();
            if (dataCount == 0)
            {
                return null;
            }
            else
            {
                List<Book> allBook = new List<Book>();
                foreach (DataRow row in objViewBookAvailable.Rows)
                {
                    Book objBook = new Book();
                    objBook.Author1 = Convert.ToInt32(row["Author"].ToString());
                    objBook.ISBN1 = row["ISBN"].ToString();
                    objBook.BookName1 = row["BookName"].ToString();
                    objBook.Publisher1 = row["Publisher"].ToString();
                    objBook.PublishYear1 = Convert.ToInt32(row["PublishYear"].ToString());
                    objBook.Pages1 = Convert.ToInt32(row["Pages"].ToString());
                    objBook.AuthorName1 = row["AuthorName"].ToString();
                    objBook.CategoryName1 = row["CategoryName"].ToString();
                    objBook.Category1 = Convert.ToInt32(row["Category"].ToString());
                    objBook.LanguageName1 = row["LanguageName"].ToString();
                    objBook.Language1 = Convert.ToInt32(row["Language"].ToString());

                    allBook.Add(objBook);

                }
                return allBook;
            }


        }

        public void borrowBooks(String ISBN, String BorrowDate, String ReturnDate, int UserID) {
            TabBorrowTableAdapter objTabBorrow = new TabBorrowTableAdapter();
            objTabBorrow.AddBorrow(UserID, ISBN, BorrowDate, ReturnDate);
        }

        public List<BorrowInstant> getAllBooksBorrowed(int UID)
        {
            TabBorrowTableAdapter objTableBorrowAdapter = new TabBorrowTableAdapter();
            BookDS.TabBorrowDataTable objTabBorrowTable = objTableBorrowAdapter.GetDataByUID(UID);

            int dataCount = objTabBorrowTable.Count();
            if (dataCount == 0)
            {
                return null;
            }
            else
            {
                List<BorrowInstant> allBook = new List<BorrowInstant>();
                foreach (DataRow row in objTabBorrowTable.Rows)
                {
                    BorrowInstant objBI = new BorrowInstant();
                    objBI.BID1 = Convert.ToInt32(row["BID"]);
                    objBI.UID1 = Convert.ToInt32(row["UID"]);
                    objBI.ISBN1 = row["ISBN"].ToString();
                    objBI.BorrorwDate1 = row["BorrowDate"].ToString();
                    objBI.ReturnDate1 = row["ReturnDate"].ToString();
                    objBI.ActualReturnDate1 = row["ActualReturnDate"].ToString();
                    objBI.LateFee1 = Convert.ToDouble(row["LateFee"]);


                   

                    allBook.Add(objBI);

                }
                return allBook;
            }
        }

        public void returnBooks(String actualReturnDate, String newActualReturnDate, String ISBN,decimal lateFee) {
            TabBorrowTableAdapter objTabBorrowAdapter = new TabBorrowTableAdapter();
            objTabBorrowAdapter.ReturningBook(newActualReturnDate, lateFee, ISBN, actualReturnDate);

        }

        public List<BorrowInstant> checkReturn(int UID,String ISBN,String actualReturnDate)
        {
            TabBorrowTableAdapter objTableBorrowAdapter = new TabBorrowTableAdapter();
            BookDS.TabBorrowDataTable objTabBorrowTable = objTableBorrowAdapter.checkReturn(UID, ISBN, actualReturnDate);

            int dataCount = objTabBorrowTable.Count();
            if (dataCount == 0)
            {
                return null;
            }
            else
            {
                List<BorrowInstant> allBook = new List<BorrowInstant>();
                foreach (DataRow row in objTabBorrowTable.Rows)
                {
                    BorrowInstant objBI = new BorrowInstant();
                    objBI.BID1 = Convert.ToInt32(row["BID"]);
                    objBI.UID1 = Convert.ToInt32(row["UID"]);
                    objBI.ISBN1 = row["ISBN"].ToString();
                    objBI.BorrorwDate1 = row["BorrowDate"].ToString();
                    objBI.ReturnDate1 = row["ReturnDate"].ToString();
                    objBI.ActualReturnDate1 = row["ActualReturnDate"].ToString();
                    objBI.LateFee1 = Convert.ToDouble(row["LateFee"]);




                    allBook.Add(objBI);

                }
                return allBook;
            }
        }
        public List<BorrowInstant> getAllBorrow()
        {
            TabBorrowTableAdapter objTableBorrowAdapter = new TabBorrowTableAdapter();
            BookDS.TabBorrowDataTable objTabBorrowTable = objTableBorrowAdapter.GetData();

            int dataCount = objTabBorrowTable.Count();
            if (dataCount == 0)
            {
                return null;
            }
            else
            {
                List<BorrowInstant> allBook = new List<BorrowInstant>();
                foreach (DataRow row in objTabBorrowTable.Rows)
                {
                    BorrowInstant objBI = new BorrowInstant();
                    objBI.BID1 = Convert.ToInt32(row["BID"]);
                    objBI.UID1 = Convert.ToInt32(row["UID"]);
                    objBI.ISBN1 = row["ISBN"].ToString();
                    objBI.BorrorwDate1 = row["BorrowDate"].ToString();
                    objBI.ReturnDate1 = row["ReturnDate"].ToString();
                    objBI.ActualReturnDate1 = row["ActualReturnDate"].ToString();
                    objBI.LateFee1 = Convert.ToDouble(row["LateFee"]);




                    allBook.Add(objBI);

                }
                return allBook;
            }
        }








    }
}

