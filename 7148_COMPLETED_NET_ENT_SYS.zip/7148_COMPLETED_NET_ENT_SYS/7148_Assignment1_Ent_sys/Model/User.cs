﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class User
    {
        private int UID;
        private String Username;
        private String Password;
        private int userLevel;
        private String Email;

        public int UID1 { get => UID; set => UID = value; }
        public string Username1 { get => Username; set => Username = value; }
        public string Password1 { get => Password; set => Password = value; }
        public int UserLevel { get => userLevel; set => userLevel = value; }
        public string Email1 { get => Email; set => Email = value; }
    }
}
