﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public interface IBookDAO
    {
        List<Book> getPublisherYear(int PublishYear);

        List<Book> getAllBook();

        List<Book> getAuthor(int Author);

        List<Book> getTitle(String Title);

        void addAuthor(String authorName);

        void addCategory(String catName);


        void addLanguage(String languageName);

        void addNewBook(String ISBN, String BookName, int Author, int Category, int Language, int PublishYear, int Pages, String Publisher);
        void updateBook(String ISBN, String BookName, int Author, int Category, int Language, int PublishYear, int Pages, String Publisher, String refISBN);

        void delete(String ISBN);

        void addBookReservation(String ISBN, int UID, String reserveDate);

        List<Book> getAllBookAvailable();

        void borrowBooks(String ISBN, String BorrowDate, String ReturnDate, int UserID);

        List<BorrowInstant> getAllBooksBorrowed(int UID);

        void returnBooks(String actualReturnDate, String newActualReturnDate, String ISBN, decimal lateFee);

        List<BorrowInstant> checkReturn(int UID, String ISBN, String actualReturnDate);

        List<BorrowInstant> getAllBorrow();




    }
}
