﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
   public interface IUserDAO
    {
         User getUserAttribute(String Username, String Password);

         void registerNewUser(String Username, String Password, int userLevel, String Email);

        void deleteExistingUser(String Username);

        String getPassword(String password);
        void changePassword(String Password,String oriPassword,String username);

       





    }
}
