﻿namespace Model
{


    partial class BookDS
    {
    }
}


namespace Model.BookDSTableAdapters {
    
    
    public partial class TabAuthorTableAdapter {
    }
}
