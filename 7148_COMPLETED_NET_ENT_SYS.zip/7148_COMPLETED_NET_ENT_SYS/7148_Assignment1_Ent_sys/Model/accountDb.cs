﻿namespace Model
{


    partial class accountDb
    {
    }
}

