﻿using Model.BookDSTableAdapters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class bookLogic: IBookLogic
    {
        public List<Book> getBookByPublisherYear(int PublishYear)
        {
            IBookDAO objBookDAO = new BookDAO();
            List<Book> objBook = objBookDAO.getPublisherYear(PublishYear);
            return objBook;
        }

        public List<Book> getAllBook()
        {
            IBookDAO objBookDAO = new BookDAO();
            List<Book> allBook = objBookDAO.getAllBook();
            return allBook;
        }

        public List<Book> getBookByAuthor(int Author)
        {
            IBookDAO objBookDAO = new BookDAO();
            List<Book> objBook = objBookDAO.getAuthor(Author);
            return objBook;
        }

        public List<Book> getBookByTitle(String title)
        {
            IBookDAO objBookDAO = new BookDAO();
            List<Book> objBook = objBookDAO.getTitle(title);
            return objBook;
        }

        public void addAuthor(String authorName) {
            IBookDAO objBookDao = new BookDAO();
            objBookDao.addAuthor(authorName);
        }

        public void addCategory(String catName) {
            IBookDAO objBookDao = new BookDAO();
            objBookDao.addCategory(catName);
        }

        public void addLanguage(String langName)
        {
            IBookDAO objBookDao = new BookDAO();
            objBookDao.addCategory(langName);
        }

        public void addNewBook(String ISBN, String BookName, int Author, int Category, int Language, int PublishYear, int Pages, String Publisher) {
            IBookDAO objBookDao = new BookDAO();
            objBookDao.addNewBook(ISBN, BookName, Author, Category, Language, PublishYear, Pages, Publisher);
        }

        public void UpdateBook(String ISBN, String BookName, int Author, int Category, int Language, int PublishYear, int Pages, String Publisher,String refISBN)
        {
            IBookDAO objBookDao = new BookDAO();
            objBookDao.updateBook(ISBN, BookName, Author, Category, Language, PublishYear, Pages, Publisher,refISBN);
        }

        public void deleteBook(String ISBN)
        {

            IBookDAO objBookDao = new BookDAO();
            objBookDao.delete(ISBN);
        }

        public void addReservation(String ISBN, int UID, String resDate) {

            IBookDAO objBookDao = new BookDAO();
            objBookDao.addBookReservation(ISBN,UID,resDate);
        }

        public bool validationReserve(String ISBN) {
            ViewBookAvailableTableAdapter objViewBookAvai = new ViewBookAvailableTableAdapter();
            BookDS.ViewBookAvailableDataTable objViewBookAvaiDT = objViewBookAvai.GetDataByISBN(ISBN);

            int dataCount = objViewBookAvaiDT.Count();

            if (dataCount <=0)
            {
                return false;
            }
            else {
                return true; 
           }
        }


        public List<Book> getAllBookAvailable()
        {
            IBookDAO objBookDAO = new BookDAO();
            List<Book> allBook = objBookDAO.getAllBookAvailable();
            return allBook;
        }

        public void addBorrowBook(String ISBN, String BorrowDate, String ReturnDate, int UserID) {
            IBookDAO objBookDao = new BookDAO();
            objBookDao.borrowBooks(ISBN, BorrowDate, ReturnDate, UserID);
        
        }

        public List<BorrowInstant> getAllBorrowedBooks(int UID)
        {

            IBookDAO objBookDAO = new BookDAO();
            List<BorrowInstant> allBook = objBookDAO.getAllBooksBorrowed(UID);
            return allBook;

        }

        public void returnBooks(String actualReturnDate, String newActualReturnDate, String ISBN, decimal lateFee) {
            IBookDAO objBookDao = new BookDAO();
            objBookDao.returnBooks(actualReturnDate, newActualReturnDate, ISBN, lateFee);
        }

        public bool validationReturn(String ISBN,String ActualReturnDate, int UID) {
            IBookDAO objBookDao = new BookDAO();
            List<BorrowInstant> tempObj = new List<BorrowInstant>();
            tempObj = objBookDao.checkReturn(UID, ISBN, ActualReturnDate);

            if (tempObj == null)
            {
                return false;
            }
            else {
                return true;
                }

        }

        public List<BorrowInstant> getBookLateFee(int UID,String ISBN,String ActualReturnDate)
        {

            IBookDAO objBookDAO = new BookDAO();
            List<BorrowInstant> allBook = objBookDAO.checkReturn(UID, ISBN, ActualReturnDate);
            return allBook;

        }

        public List<BorrowInstant> getAllBorrowedBooksAdmin()
        {

            IBookDAO objBookDAO = new BookDAO();
            List<BorrowInstant> allBook = objBookDAO.getAllBorrow();
            return allBook;

        }



    }
}
