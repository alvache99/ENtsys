﻿using Model.accountDbTableAdapters;
using Model.BookDSTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class userDAO : IUserDAO
    {
        public User getUserAttribute(String Username, String Password)
        {
            TabUserTableAdapter objTabUserTableAdapter = new TabUserTableAdapter();
            accountDb.TabUserDataTable objTabUserDataTable = objTabUserTableAdapter.GetUserByUserAttribute(Username, Password);

            int receivedValidationCount = objTabUserDataTable.Count();
            User recUser = null;
            


            if (receivedValidationCount == 1) {
                foreach (DataRow selectedUser in objTabUserDataTable.Rows) {

                  recUser = new User();
                  recUser.UID1 = Convert.ToInt32(selectedUser["UID"].ToString());
                  recUser.Username1 =selectedUser["UserName"].ToString();
                  recUser.Password1 = selectedUser["Password"].ToString();
                  recUser.UserLevel = Convert.ToInt32(selectedUser["UserLevel"].ToString());
                  recUser.Email1 = selectedUser["UserEmail"].ToString();
                }

            }
            else {
                recUser = null;
            }

            return recUser;
        }

        public void registerNewUser(String Username, String Password, int userLevel, String Email) {
            TabUserTableAdapter objTabUserTableAdapter = new TabUserTableAdapter();
            objTabUserTableAdapter.SaveNewAttribute( Username,  Password,  userLevel,  Email);
        }

        public void deleteExistingUser(String Username) {
            TabUserTableAdapter objTabUserTableAdapter = new TabUserTableAdapter();
            objTabUserTableAdapter.DeleteAccount(Username);
        }

        public void changePassword(String Password, String oriPassword,String username) {
            TabUserTableAdapter objTabUserTableAdapter = new TabUserTableAdapter();
            objTabUserTableAdapter.ChangePassword(Password,oriPassword,username);
        }

        public String getPassword(String Password) {
            TabUserTableAdapter objTabUserTableAdapter = new TabUserTableAdapter();
            String resultPw = (objTabUserTableAdapter.GetPassword(Password)).ToString();
            return resultPw;
        }

        

        

    }
}
