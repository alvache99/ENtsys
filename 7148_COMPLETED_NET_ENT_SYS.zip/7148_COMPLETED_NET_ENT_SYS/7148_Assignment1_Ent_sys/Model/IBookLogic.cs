﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public interface IBookLogic
    {
        List<Book> getBookByPublisherYear(int PublishYear);

        List<Book> getBookByAuthor(int Author);

        List<Book> getBookByTitle(String title);


        List<Book> getAllBook();

        void addAuthor(String authorName);

         void addCategory(String catName);


         void addLanguage(String langName);


        void addNewBook(String ISBN, String BookName, int Author, int Category, int Language, int PublishYear, int Pages, String Publisher);

        void UpdateBook(String ISBN, String BookName, int Author, int Category, int Language, int PublishYear, int Pages, String Publisher, String refISBN);

        void deleteBook(String ISBN);

        void addReservation(String ISBN, int UID, String resDate);

         bool validationReserve(String ISBN);

        List<Book> getAllBookAvailable();

        void addBorrowBook(String ISBN, String BorrowDate, String ReturnDate, int UserID);

        List<BorrowInstant> getAllBorrowedBooks(int UID);
        bool validationReturn(String ISBN, String ActualReturnDate, int UID);

        void returnBooks(String actualReturnDate, String newActualReturnDate, String ISBN, decimal lateFee);

        List<BorrowInstant> getBookLateFee(int UID, String ISBN, String ActualReturnDate);

        List<BorrowInstant> getAllBorrowedBooksAdmin();



    }
}
