﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Book
    {
        private String ISBN;
        private String BookName;
        private String Publisher;
        private int PublishYear;
        private int Pages;
        private String AuthorName;
        private String CategoryName;
        private String LanguageName;
        private int Author;
        private int Category;
        private int Language;

        public string ISBN1 { get => ISBN; set => ISBN = value; }
        public string BookName1 { get => BookName; set => BookName = value; }
        public string Publisher1 { get => Publisher; set => Publisher = value; }
        public int PublishYear1 { get => PublishYear; set => PublishYear = value; }
        public int Pages1 { get => Pages; set => Pages = value; }
        public string AuthorName1 { get => AuthorName; set => AuthorName = value; }
        public string CategoryName1 { get => CategoryName; set => CategoryName = value; }
        public string LanguageName1 { get => LanguageName; set => LanguageName = value; }
        public int Author1 { get => Author; set => Author = value; }
        public int Category1 { get => Category; set => Category = value; }
        public int Language1 { get => Language; set => Language = value; }
    }
}
