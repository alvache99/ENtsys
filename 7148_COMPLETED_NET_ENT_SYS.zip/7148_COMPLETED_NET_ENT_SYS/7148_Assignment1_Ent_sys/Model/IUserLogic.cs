﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
     public interface IUserLogic
    {
         bool validationLogin(String Username, String Password);
        void saveNewUser(String Username, String Password, int userLevel, String Email);

        bool attributeCheckUserLogic(String Username, String Email);
        void deleteAccount(String Username);

        bool validationChangePw(String firstPw, String secondPw);


        void passwordChange(String password, String oriPassword,String username);

        String getPassword(String password);

        User getUser(String Username, String Password);
       


    }
}
