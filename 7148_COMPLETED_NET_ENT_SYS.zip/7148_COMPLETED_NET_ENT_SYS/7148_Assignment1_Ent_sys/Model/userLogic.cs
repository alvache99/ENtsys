﻿using Model.accountDbTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class userLogic : IUserLogic
    {

        public User getUser(String Username, String Password) {
            IUserDAO objUserDAO = new userDAO();
            User refUser ;
            refUser = objUserDAO.getUserAttribute(Username, Password);

            return refUser;
        }

        public bool validationLogin(String Username, String Password) {
            IUserDAO objUserDAO = new userDAO();
            User refUser = new User();

            refUser = objUserDAO.getUserAttribute(Username, Password);

            if (refUser != null)
            {
                return true;
            }
            else   {
                return false;
            }


        }

        public void saveNewUser(String Username, String Password, int userLevel, String Email) {
            IUserDAO objUserDAO = new userDAO();
            objUserDAO.registerNewUser(Username, Password, userLevel, Email);

        }
        public bool attributeCheckUserLogic(String Username, String Email) {
            int countEmail = 0;
            int countUsername = 0;
            TabUserTableAdapter objTabUserTableAdapter = new TabUserTableAdapter();
            accountDb.TabUserDataTable objTabUserDataTable = objTabUserTableAdapter.GetData();
            foreach (DataRow checkRow in objTabUserDataTable.Rows) {
                if ( Email== Convert.ToString(checkRow["UserEmail"])) {
                    countEmail++;
                }
                if (Username == Convert.ToString(checkRow["UserName"]))
                {
                    countUsername++;
                }
            }
            if (countUsername > 0 && countEmail > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void deleteAccount(String Username) {
            IUserDAO objUserDao = new userDAO();
            objUserDao.deleteExistingUser(Username);
        }

        public bool validationChangePw(String firstPw, String secondPw) {
            if (firstPw == secondPw)
            {
                return true;
            }
            else {
                return false;
            }
        }

        public void passwordChange(String password, String oriPassword,String username) {
            IUserDAO objUserDao = new userDAO();
            objUserDao.changePassword(password, oriPassword,username);
        }

        public String getPassword(String password) {
            IUserDAO objUserDao = new userDAO();
            return objUserDao.getPassword(password);
        }







    }
}
