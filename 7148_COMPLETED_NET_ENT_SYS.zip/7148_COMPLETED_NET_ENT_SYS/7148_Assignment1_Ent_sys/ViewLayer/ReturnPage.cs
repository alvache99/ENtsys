﻿using Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ViewLayer
{
    public partial class ReturnPage : Form
    {
        public ReturnPage()
        {
            InitializeComponent();
            IBookController objBookController = new bookController();

            List<borrowDTO> allBorrowedBooks = objBookController.getAllBooksBorrowed(Globals.UID);

            if (allBorrowedBooks == null)
            {
                MessageBox.Show("You have not borrowed any books!!");
            }
            else
            {
                returnGridView.DataSource = allBorrowedBooks;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }


        //IT SHOWS THE BOOKS USER BORROWED!!!
        private void button2_Click(object sender, EventArgs e)
        {
            IBookController objBookController = new bookController();
            
            List<borrowDTO> allBorrowedBooks = objBookController.getAllBooksBorrowed(Globals.UID);

            if (allBorrowedBooks == null)
            {
                MessageBox.Show("You have not borrowed any books!!");
            }
            else
            {
                returnGridView.DataSource = allBorrowedBooks;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IBookController objBookController = new bookController();
            DateTime defaultDateTime = new DateTime(2000, 01, 01);
            decimal lateFee = 0;



            if (objBookController.returnCheck(returnBox.Text, defaultDateTime.ToString(), Globals.UID)==true) {
                List<borrowDTO> lateRef = new List<borrowDTO>();
                lateRef = objBookController.getLateFeeRef(returnBox.Text, Globals.UID, defaultDateTime.ToString());

                //Return date surpassed. Late fees applied if not it stays at 0
                if (Convert.ToDateTime(lateRef[0].ReturnDate1) < DateTime.Today) {
                    lateFee = 15;
                }
                else
                {
                    lateFee = 0;
                }


                objBookController.returnBook(defaultDateTime.ToString(), DateTime.Now.ToString("yyyy-MM-dd"), returnBox.Text, lateFee);
                MessageBox.Show("Book Return Success!!");
            }
            else
            {

                MessageBox.Show("No borrowed books found for return!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MainForm objMainForm = new MainForm();
            objMainForm.ShowDialog();
        }
    }
}
