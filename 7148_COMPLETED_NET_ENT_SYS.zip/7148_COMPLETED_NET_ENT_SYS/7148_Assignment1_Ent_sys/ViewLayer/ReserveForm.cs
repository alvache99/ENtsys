﻿using Controller;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ViewLayer
{
    public partial class ReserveForm : Form
    {
        public ReserveForm()
        {
            InitializeComponent();
            IBookController objBookController = new bookController();
            List<bookAllDTO> allBook = objBookController.getAllBooksAvailable();

            if (allBook == null)
            {
                MessageBox.Show("No Books Found!");
            }
            else
            {
                dataGridViewReserve.DataSource = allBook;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IBookController objBookController = new bookController();
            bool TempBoolCheck =  objBookController.validationReserve(reserveBox.Text);
            if (TempBoolCheck == true) {
                objBookController.addBookReserve(reserveBox.Text,Globals.UID, DateTime.Now.ToString("yyyy-MM-dd"));
                MessageBox.Show("Reserve added completed!");
            }
            else
            {
                MessageBox.Show("Book not available!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MainForm objMain = new MainForm();
            objMain.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            IBookController objBookController = new bookController();
            List<bookAllDTO> allBook = objBookController.getAllBooksAvailable();

            if (allBook == null)
            {
                MessageBox.Show("No Books Found!");
            }
            else
            {
                dataGridViewReserve.DataSource = allBook;
            }
        }
    }
}
