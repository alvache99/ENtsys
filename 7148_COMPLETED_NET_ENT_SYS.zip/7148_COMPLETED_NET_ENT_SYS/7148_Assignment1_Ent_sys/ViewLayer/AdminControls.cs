﻿using Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ViewLayer
{
    public partial class AdminControls : Form
    {
        public AdminControls()
        {
            InitializeComponent();
        }

        

        private void browseButtonAd_Click(object sender, EventArgs e)
        {
            IBookController objBookController = new bookController();
            List<bookAllDTO> allBook = objBookController.getAllBooks();

            if (allBook == null)
            {
                MessageBox.Show("No Books Found!");
            }
            else
            {
                dataGridViewAd.DataSource = allBook;
            }
        }

       

        private void ClearGridViewAd_Click(object sender, EventArgs e)
        {
            dataGridViewAd.DataSource = null;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(tableCodeBox.Text) == 4)
            {
                IBookController objBookController = new bookController();
                objBookController.addBookAuthor(authorBox.Text);
                MessageBox.Show("New Author add successful!");
            }
            else if (Convert.ToInt32(tableCodeBox.Text) == 1)
            {
                IBookController objBookController = new bookController();
                objBookController.addCategory(catBox.Text);
                MessageBox.Show("New category add successful!");
            }
            else if (Convert.ToInt32(tableCodeBox.Text) == 2)
            {
                IBookController objBookController = new bookController();
                objBookController.addLanguage(langBox.Text);
                MessageBox.Show("New Language add successful!");
            }
            else if (Convert.ToInt32(tableCodeBox.Text) == 3)
            {
                IBookController objBookController = new bookController();
                objBookController.addNewBook(isbnBox.Text,booknameBox.Text,Convert.ToInt32(authorNumBox.Text),Convert.ToInt32(catNumBox.Text),Convert.ToInt32(langNumBox.Text),Convert.ToInt32(pubYearBox.Text),Convert.ToInt32(pagesBox.Text),pubYearBox.Text);
                MessageBox.Show("New book add successful!");
            }

            else {
                MessageBox.Show("Invalid Table Code");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            IBookController bookController = new bookController();
            bookController.updateBook(isbnBox.Text, booknameBox.Text, Convert.ToInt32(authorNumBox.Text), Convert.ToInt32(catNumBox.Text), Convert.ToInt32(langNumBox.Text), Convert.ToInt32(pubYearBox.Text), Convert.ToInt32(pagesBox.Text), pubYearBox.Text,refISBNBOX.Text);
            MessageBox.Show("Update Completed!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            IBookController bookController = new bookController();
            bookController.deleteBook(refISBNBOX.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainForm objMainForm = new MainForm();
            objMainForm.ShowDialog();
        }
    }
}
