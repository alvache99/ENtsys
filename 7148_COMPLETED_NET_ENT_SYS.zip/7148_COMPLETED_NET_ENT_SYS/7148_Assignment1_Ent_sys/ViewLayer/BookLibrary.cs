﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Controller;
namespace ViewLayer
{
    public partial class BookLibrary : Form
    {
        public BookLibrary()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void PublishYearSearch_Click(object sender, EventArgs e)
        {
            IBookController objBookController = new bookController();
            List<bookAllDTO> objBookDTO = objBookController.getBooksByPublishYear(Convert.ToInt32(searchBox.Text));
           
            if (objBookDTO == null)
            {
                MessageBox.Show("No books found in this publish year!");
            }
            else {

                dataGridView1.DataSource = objBookDTO;

            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            searchBox.Text = "";
        }

        private void browseButton_Click(object sender, EventArgs e)
        {
            IBookController objBookController = new bookController();
            List<bookAllDTO> allBook = objBookController.getAllBooks();
            
            if (allBook == null)
            {
                MessageBox.Show("No Books Found!");
            }
            else {
                dataGridView1.DataSource = allBook;              
            }
        }

        private void ClearGridView_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
        }

        private void searchAuthorButton_Click(object sender, EventArgs e)
        {
            IBookController objBookController = new bookController();
            List<bookAllDTO> objBookDTO = objBookController.getBooksByAuthor(Convert.ToInt32(searchBox.Text));

            if (objBookDTO == null)
            {
                MessageBox.Show("No books found with this Author number!!");
            }
            else
            {

                dataGridView1.DataSource = objBookDTO;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IBookController objBookController = new bookController();
            List<bookAllDTO> objBookDTO = objBookController.getBooksByTitle(searchBox.Text);

            if (objBookDTO == null)
            {
                MessageBox.Show("No books found with this Author number!!");
            }
            else
            {

                dataGridView1.DataSource = objBookDTO;

            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MainForm objMainForm = new MainForm();
            objMainForm.ShowDialog();
        }
    }
}
