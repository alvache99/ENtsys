﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Controller;
namespace ViewLayer
{
    public partial class Form1 : Form
    {
        private userDTO loggedInUser;
        public String passwordChgUser;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public userDTO getUser() {
            return loggedInUser;
        }
        public void setUser(userDTO setUserRef) {
            loggedInUser = setUserRef;
        }
        private void loginButton_Click(object sender, EventArgs e)
        {
            

            //USE THIS TO LOG IN ID = user, PASSWORD = User1234 OR Use the sign up feature to sign up account. SAME USERNAME SIGNUP ERROR HANDLING ISN'T IMPLEMENTED
            IUserController objUserController = new UserController();
            bool valCheck = objUserController.accValidation(usernameTextbox.Text, passwordTextbox.Text);

            if (valCheck == true)
            {
                loggedInUser = objUserController.getUserCtrl(usernameTextbox.Text, passwordTextbox.Text);
                Globals.UID = loggedInUser.UID1;
                Globals.Username = loggedInUser.Username1;
                MainForm objMainForm = new MainForm();
                objMainForm.ShowDialog();
                
                
            }
            else {
                MessageBox.Show("Incorrect username/password! Please retry");
            }
        }

        private void signupButton_Click(object sender, EventArgs e)
        {
            Signup objSignUpForm = new Signup();
            objSignUpForm.ShowDialog();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
            IUserController objUserController = new UserController();                           
            ChangePW objChangePw = new ChangePW();
            objChangePw.ShowDialog();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            IUserController objUserController = new UserController();
            bool valCheck = objUserController.accValidation(usernameTextbox.Text, passwordTextbox.Text);

            if (valCheck == true)
            {
                objUserController.deleteAcc(usernameTextbox.Text);
                usernameTextbox.Text = "";
                passwordTextbox.Text = "";
                MessageBox.Show("Account deactivated successfully");
            }
            else
            {
                MessageBox.Show("Incorrect username/password! Please retry");
            }
        }
    }
}
