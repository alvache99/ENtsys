﻿using Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ViewLayer
{
    public partial class ChangePW : Form
    {
        public ChangePW()
        {
            InitializeComponent();
        }

        private void Confirm_Click(object sender, EventArgs e)
        {
            Form1 objForm1 = new Form1();
            IUserController objUserController = new UserController();
            bool tempCheck = objUserController.validationChangePw(NewPW.Text, cfmNewPW.Text);
            bool tempCheck2 = objUserController.accValidation(usernameTxtBoxChg.Text, oldPassBox.Text);
            if (tempCheck == true && tempCheck2 == true) {
               objUserController.passwordChange(NewPW.Text,oldPassBox.Text,usernameTxtBoxChg.Text);
                MessageBox.Show("Password Changed successfully!");
                
                objForm1.ShowDialog();
            }
            else
            {
                MessageBox.Show("Your password or account does not match! Try again!");

            }
        }

        private void Back_Click(object sender, EventArgs e)
        {
            Form1 objForm1 = new Form1();
            objForm1.passwordChgUser = null;
            objForm1.ShowDialog();

        }
    }
}
