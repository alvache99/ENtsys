﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Controller;
namespace ViewLayer
{
    public partial class Signup : Form
    {
        public Signup()
        {
            InitializeComponent();
        }

        private void confirmButton_Click(object sender, EventArgs e)
        {

            IUserController objUserController = new UserController();

            bool charCheck = objUserController.attributeCheck(newUsernameTextbox.Text, emailTextbox.Text);

            if (charCheck == true)
            {
                MessageBox.Show("Email or Username has been used! Please Retry!");
            }
            else {
                objUserController.registerAcc(newUsernameTextbox.Text, newPasswordTextbox.Text, Convert.ToInt32(userLevelTextbox.Text), emailTextbox.Text);
                MessageBox.Show("Registration completed!");

            }

        }

        private void backButton_Click(object sender, EventArgs e)
        {
            Form1 objForm1 = new Form1();
            objForm1.ShowDialog();
        }
    }
}
