﻿namespace ViewLayer
{
    partial class AdminControls
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.ClearGridViewAd = new System.Windows.Forms.Button();
            this.dataGridViewAd = new System.Windows.Forms.DataGridView();
            this.browseButtonAd = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.catBox = new System.Windows.Forms.TextBox();
            this.tableCodeBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.authorBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.langBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.booknameBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.isbnBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.catNumBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.authorNumBox = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.publisherBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.pagesBox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.pubYearBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.langNumBox = new System.Windows.Forms.TextBox();
            this.bookPickISBNbox = new System.Windows.Forms.Label();
            this.refISBNBOX = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAd)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Lime;
            this.label2.Location = new System.Drawing.Point(217, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(315, 37);
            this.label2.TabIndex = 21;
            this.label2.Text = "Book Data Grid View";
            // 
            // ClearGridViewAd
            // 
            this.ClearGridViewAd.Location = new System.Drawing.Point(665, 580);
            this.ClearGridViewAd.Name = "ClearGridViewAd";
            this.ClearGridViewAd.Size = new System.Drawing.Size(122, 26);
            this.ClearGridViewAd.TabIndex = 20;
            this.ClearGridViewAd.Text = "ClearGridView";
            this.ClearGridViewAd.UseVisualStyleBackColor = true;
            this.ClearGridViewAd.Click += new System.EventHandler(this.ClearGridViewAd_Click);
            // 
            // dataGridViewAd
            // 
            this.dataGridViewAd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAd.Location = new System.Drawing.Point(12, 50);
            this.dataGridViewAd.Name = "dataGridViewAd";
            this.dataGridViewAd.Size = new System.Drawing.Size(734, 196);
            this.dataGridViewAd.TabIndex = 19;
            // 
            // browseButtonAd
            // 
            this.browseButtonAd.Location = new System.Drawing.Point(510, 516);
            this.browseButtonAd.Name = "browseButtonAd";
            this.browseButtonAd.Size = new System.Drawing.Size(122, 26);
            this.browseButtonAd.TabIndex = 14;
            this.browseButtonAd.Text = "Browse All Books";
            this.browseButtonAd.UseVisualStyleBackColor = true;
            this.browseButtonAd.Click += new System.EventHandler(this.browseButtonAd_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(510, 548);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(122, 26);
            this.button1.TabIndex = 22;
            this.button1.Text = "Insert";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(665, 516);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(122, 26);
            this.button2.TabIndex = 23;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(510, 580);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(122, 26);
            this.button3.TabIndex = 24;
            this.button3.Text = "Update";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(665, 548);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(122, 26);
            this.button4.TabIndex = 25;
            this.button4.Text = "Back";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 377);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 13);
            this.label3.TabIndex = 27;
            this.label3.Text = "Category Name:";
            // 
            // catBox
            // 
            this.catBox.Location = new System.Drawing.Point(101, 374);
            this.catBox.Name = "catBox";
            this.catBox.Size = new System.Drawing.Size(120, 20);
            this.catBox.TabIndex = 26;
            // 
            // tableCodeBox
            // 
            this.tableCodeBox.Location = new System.Drawing.Point(101, 311);
            this.tableCodeBox.Name = "tableCodeBox";
            this.tableCodeBox.Size = new System.Drawing.Size(120, 20);
            this.tableCodeBox.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 318);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 29;
            this.label4.Text = "Table Code:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 281);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(388, 13);
            this.label5.TabIndex = 30;
            this.label5.Text = "Table Code: 1(TableCategory), 2(TableLanguage), 3(TableBook), 4(TableAuthor)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 402);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 13);
            this.label7.TabIndex = 34;
            this.label7.Text = "Author Name:";
            // 
            // authorBox
            // 
            this.authorBox.Location = new System.Drawing.Point(101, 399);
            this.authorBox.Name = "authorBox";
            this.authorBox.Size = new System.Drawing.Size(120, 20);
            this.authorBox.TabIndex = 33;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 429);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 13);
            this.label6.TabIndex = 38;
            this.label6.Text = "Language Name:";
            // 
            // langBox
            // 
            this.langBox.Location = new System.Drawing.Point(101, 426);
            this.langBox.Name = "langBox";
            this.langBox.Size = new System.Drawing.Size(120, 20);
            this.langBox.TabIndex = 37;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(277, 377);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(66, 13);
            this.label10.TabIndex = 42;
            this.label10.Text = "Book Name:";
            // 
            // booknameBox
            // 
            this.booknameBox.Location = new System.Drawing.Point(366, 374);
            this.booknameBox.Name = "booknameBox";
            this.booknameBox.Size = new System.Drawing.Size(120, 20);
            this.booknameBox.TabIndex = 41;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(277, 353);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 13);
            this.label11.TabIndex = 40;
            this.label11.Text = "ISBN :";
            // 
            // isbnBox
            // 
            this.isbnBox.Location = new System.Drawing.Point(366, 350);
            this.isbnBox.Name = "isbnBox";
            this.isbnBox.Size = new System.Drawing.Size(120, 20);
            this.isbnBox.TabIndex = 39;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(277, 426);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 13);
            this.label12.TabIndex = 46;
            this.label12.Text = "Category:";
            // 
            // catNumBox
            // 
            this.catNumBox.Location = new System.Drawing.Point(366, 423);
            this.catNumBox.Name = "catNumBox";
            this.catNumBox.Size = new System.Drawing.Size(120, 20);
            this.catNumBox.TabIndex = 45;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(277, 402);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 13);
            this.label13.TabIndex = 44;
            this.label13.Text = "Author :";
            // 
            // authorNumBox
            // 
            this.authorNumBox.Location = new System.Drawing.Point(366, 399);
            this.authorNumBox.Name = "authorNumBox";
            this.authorNumBox.Size = new System.Drawing.Size(120, 20);
            this.authorNumBox.TabIndex = 43;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(491, 423);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 13);
            this.label14.TabIndex = 54;
            this.label14.Text = "Publisher:";
            // 
            // publisherBox
            // 
            this.publisherBox.Location = new System.Drawing.Point(580, 420);
            this.publisherBox.Name = "publisherBox";
            this.publisherBox.Size = new System.Drawing.Size(120, 20);
            this.publisherBox.TabIndex = 53;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(491, 399);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 13);
            this.label15.TabIndex = 52;
            this.label15.Text = "Pages :";
            // 
            // pagesBox
            // 
            this.pagesBox.Location = new System.Drawing.Point(580, 396);
            this.pagesBox.Name = "pagesBox";
            this.pagesBox.Size = new System.Drawing.Size(120, 20);
            this.pagesBox.TabIndex = 51;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(491, 374);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 13);
            this.label16.TabIndex = 50;
            this.label16.Text = "Publish Year:";
            // 
            // pubYearBox
            // 
            this.pubYearBox.Location = new System.Drawing.Point(580, 371);
            this.pubYearBox.Name = "pubYearBox";
            this.pubYearBox.Size = new System.Drawing.Size(120, 20);
            this.pubYearBox.TabIndex = 49;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(491, 350);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 13);
            this.label17.TabIndex = 48;
            this.label17.Text = "Language :";
            // 
            // langNumBox
            // 
            this.langNumBox.Location = new System.Drawing.Point(580, 347);
            this.langNumBox.Name = "langNumBox";
            this.langNumBox.Size = new System.Drawing.Size(120, 20);
            this.langNumBox.TabIndex = 47;
            // 
            // bookPickISBNbox
            // 
            this.bookPickISBNbox.AutoSize = true;
            this.bookPickISBNbox.Location = new System.Drawing.Point(405, 324);
            this.bookPickISBNbox.Name = "bookPickISBNbox";
            this.bookPickISBNbox.Size = new System.Drawing.Size(84, 13);
            this.bookPickISBNbox.TabIndex = 56;
            this.bookPickISBNbox.Text = "BookPick ISBN:";
            // 
            // refISBNBOX
            // 
            this.refISBNBOX.Location = new System.Drawing.Point(494, 321);
            this.refISBNBOX.Name = "refISBNBOX";
            this.refISBNBOX.Size = new System.Drawing.Size(120, 20);
            this.refISBNBOX.TabIndex = 55;
            // 
            // AdminControls
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(920, 621);
            this.Controls.Add(this.bookPickISBNbox);
            this.Controls.Add(this.refISBNBOX);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.publisherBox);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.pagesBox);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.pubYearBox);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.langNumBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.catNumBox);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.authorNumBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.booknameBox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.isbnBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.langBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.authorBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tableCodeBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.catBox);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ClearGridViewAd);
            this.Controls.Add(this.dataGridViewAd);
            this.Controls.Add(this.browseButtonAd);
            this.Name = "AdminControls";
            this.Text = "AdminControls";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ClearGridViewAd;
        private System.Windows.Forms.DataGridView dataGridViewAd;
        private System.Windows.Forms.Button browseButtonAd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox catBox;
        private System.Windows.Forms.TextBox tableCodeBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox authorBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox langBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox booknameBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox isbnBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox catNumBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox authorNumBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox publisherBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox pagesBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox pubYearBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox langNumBox;
        private System.Windows.Forms.Label bookPickISBNbox;
        private System.Windows.Forms.TextBox refISBNBOX;
    }
}