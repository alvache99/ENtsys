﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewLayer
{
    public static class Globals
    {
        
        public static String Username;
        public static int UID;
        public const String adminUsername = "admin2323";
        public const String adminPassword = "9956874asdw";



    }
}
