﻿namespace ViewLayer
{
    partial class BookLibrary
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.searchPublishYearButton = new System.Windows.Forms.Button();
            this.browseButton = new System.Windows.Forms.Button();
            this.searchBox = new System.Windows.Forms.TextBox();
            this.searchAuthorButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ClearGridView = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // searchPublishYearButton
            // 
            this.searchPublishYearButton.Location = new System.Drawing.Point(117, 352);
            this.searchPublishYearButton.Name = "searchPublishYearButton";
            this.searchPublishYearButton.Size = new System.Drawing.Size(122, 23);
            this.searchPublishYearButton.TabIndex = 1;
            this.searchPublishYearButton.Text = "Search Publish Year";
            this.searchPublishYearButton.UseVisualStyleBackColor = true;
            this.searchPublishYearButton.Click += new System.EventHandler(this.PublishYearSearch_Click);
            // 
            // browseButton
            // 
            this.browseButton.Location = new System.Drawing.Point(117, 440);
            this.browseButton.Name = "browseButton";
            this.browseButton.Size = new System.Drawing.Size(122, 26);
            this.browseButton.TabIndex = 2;
            this.browseButton.Text = "Browse All Books";
            this.browseButton.UseVisualStyleBackColor = true;
            this.browseButton.Click += new System.EventHandler(this.browseButton_Click);
            // 
            // searchBox
            // 
            this.searchBox.Location = new System.Drawing.Point(118, 318);
            this.searchBox.Name = "searchBox";
            this.searchBox.Size = new System.Drawing.Size(225, 20);
            this.searchBox.TabIndex = 4;
            this.searchBox.TextChanged += new System.EventHandler(this.searchBox_TextChanged);
            // 
            // searchAuthorButton
            // 
            this.searchAuthorButton.Location = new System.Drawing.Point(274, 352);
            this.searchAuthorButton.Name = "searchAuthorButton";
            this.searchAuthorButton.Size = new System.Drawing.Size(121, 23);
            this.searchAuthorButton.TabIndex = 5;
            this.searchAuthorButton.Text = "Search Author";
            this.searchAuthorButton.UseVisualStyleBackColor = true;
            this.searchAuthorButton.Click += new System.EventHandler(this.searchAuthorButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(274, 392);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(121, 26);
            this.clearButton.TabIndex = 7;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 321);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Search bar :";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 53);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(776, 247);
            this.dataGridView1.TabIndex = 9;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // ClearGridView
            // 
            this.ClearGridView.Location = new System.Drawing.Point(662, 306);
            this.ClearGridView.Name = "ClearGridView";
            this.ClearGridView.Size = new System.Drawing.Size(86, 32);
            this.ClearGridView.TabIndex = 10;
            this.ClearGridView.Text = "ClearGridView";
            this.ClearGridView.UseVisualStyleBackColor = true;
            this.ClearGridView.Click += new System.EventHandler(this.ClearGridView_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Lime;
            this.label2.Location = new System.Drawing.Point(217, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(315, 37);
            this.label2.TabIndex = 11;
            this.label2.Text = "Book Data Grid View";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(118, 396);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 22);
            this.button1.TabIndex = 12;
            this.button1.Text = "Search Title";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(274, 440);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(121, 26);
            this.button2.TabIndex = 13;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // BookLibrary
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 506);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ClearGridView);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.searchAuthorButton);
            this.Controls.Add(this.searchBox);
            this.Controls.Add(this.browseButton);
            this.Controls.Add(this.searchPublishYearButton);
            this.Name = "BookLibrary";
            this.Text = "MainPage";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DB_A57252_B20ES7148DataSet dB_A57252_B20ES7148DataSet;
        private System.Windows.Forms.Button searchPublishYearButton;
        private System.Windows.Forms.Button browseButton;
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.Button searchAuthorButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button ClearGridView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private DB_A57252_B20ES7148DataSet dB_A57252_B20ES7148DataSet1;
        private System.Windows.Forms.Button button2;
    }
}