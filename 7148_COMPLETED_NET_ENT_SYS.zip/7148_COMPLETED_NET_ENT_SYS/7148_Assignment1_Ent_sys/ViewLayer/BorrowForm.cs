﻿using Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ViewLayer
{
    public partial class BorrowForm : Form
    {
        public BorrowForm()
        {
            InitializeComponent();
            IBookController objBookController = new bookController();
            List<bookAllDTO> allBook = objBookController.getAllBooksAvailable();

            if (allBook == null)
            {
                MessageBox.Show("No Books Found!");
            }
            else
            {
                dataGridViewBorrow.DataSource = allBook;
            }
        }

        private void BorrowForm_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            IBookController objBookController = new bookController();
            List<bookAllDTO> allBook = objBookController.getAllBooksAvailable();

            if (allBook == null)
            {
                MessageBox.Show("No Books Found!");
            }
            else
            {
                dataGridViewBorrow.DataSource = allBook;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            IBookController objBookController = new bookController();
            bool checkAvailability = objBookController.validationReserve(borrowBox.Text);

            if (checkAvailability == true) {

                DateTime today = DateTime.Now;
                //Set return date a week from current borrowing date.
                DateTime returnSetDate = today.AddDays(7);
                objBookController.borrowBook(borrowBox.Text, DateTime.Now.ToString("yyyy-MM-dd"), returnSetDate.ToString("yyyy-MM-dd"),Globals.UID);
                MessageBox.Show("Borrow Success!");
            }
            else
            {
                MessageBox.Show("No Books available with your ISBN!");

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MainForm objMainForm = new MainForm();
            objMainForm.ShowDialog();
        }
    }
}
