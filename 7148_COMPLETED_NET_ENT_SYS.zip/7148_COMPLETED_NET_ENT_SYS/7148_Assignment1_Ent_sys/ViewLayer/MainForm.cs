﻿using Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ViewLayer
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            labelUsername.Text = Globals.Username;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 objForm1 = new Form1();
            objForm1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Signup objSignup = new Signup();
            objSignup.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            BookLibrary objBookLibrary = new BookLibrary();
            objBookLibrary.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (adminUserBox.Text== Globals.adminUsername && adminPasswordBox.Text==Globals.adminPassword) {
                AdminControls objAdmin = new AdminControls();
                objAdmin.ShowDialog();
            }
            else
            {

                MessageBox.Show("Wrong admin username or password!");
            }


            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //Logging out set all values to default
            Globals.UID = 0;
            Globals.Username = "";
            Form1 objForm1 = new Form1();
            objForm1.ShowDialog();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            ReserveForm reserveForm = new ReserveForm();
            reserveForm.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            BorrowForm objBorrowForm = new BorrowForm();
            objBorrowForm.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ReturnPage objReturnPage = new ReturnPage();
            objReturnPage.ShowDialog();
        }

        private void usernameLabel_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (adminUserBox.Text == Globals.adminUsername && adminPasswordBox.Text == Globals.adminPassword)
            {
                ReportingForm objRF = new ReportingForm();
                objRF.ShowDialog();
            }
            else
            {

                MessageBox.Show("Wrong admin username or password!");
            }
        }

        private void adminUserBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void adminPasswordBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
