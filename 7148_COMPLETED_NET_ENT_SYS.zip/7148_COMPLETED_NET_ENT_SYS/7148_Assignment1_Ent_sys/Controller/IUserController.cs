﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controller
{
   public interface IUserController
    {
        bool accValidation(String username, String password);
        void registerAcc(String Username, String Password, int userLevel, String Email);

        bool attributeCheck(String username, String email);

        void deleteAcc(String username);

         bool validationChangePw(String firstPw, String secondPw);

         void passwordChange(String password, String oriPassword, String username);

        userDTO getUserCtrl(String Username, String Password);
       


    }
}
