﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controller
{
    public class borrowDTO
    {
        private int BID;
        private int UID;
        private String ISBN;
        private String BorrorwDate;
        private String ReturnDate;
        private String ActualReturnDate;
        private double LateFee;

        public int BID1 { get => BID; set => BID = value; }
        public int UID1 { get => UID; set => UID = value; }
        public string ISBN1 { get => ISBN; set => ISBN = value; }
        public string BorrorwDate1 { get => BorrorwDate; set => BorrorwDate = value; }
        public string ReturnDate1 { get => ReturnDate; set => ReturnDate = value; }
        public string ActualReturnDate1 { get => ActualReturnDate; set => ActualReturnDate = value; }
        public double LateFee1 { get => LateFee; set => LateFee = value; }
    }
}
