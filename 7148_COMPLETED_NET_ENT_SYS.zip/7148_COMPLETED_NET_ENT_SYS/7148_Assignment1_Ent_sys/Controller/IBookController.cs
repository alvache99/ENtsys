﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controller
{
    public interface IBookController
    {
        List<bookAllDTO> getAllBooks();

        List<bookAllDTO> getBooksByPublishYear(int publishYear);

        List<bookAllDTO> getBooksByAuthor(int Author);

        List<bookAllDTO> getBooksByTitle(String Title);
         void addBookAuthor(String authorName);
         void addCategory(String catName);


         void addLanguage(String langName);

        void addNewBook(String ISBN, String BookName, int Author, int Category, int Language, int PublishYear, int Pages, String Publisher);
         void updateBook(String ISBN, String BookName, int Author, int Category, int Language, int PublishYear, int Pages, String Publisher, String refISBN);

        void deleteBook(String refISBN);
         bool validationReserve(String ISBN);



        void addBookReserve(String ISBN, int UID, String resDate);

         List<bookAllDTO> getAllBooksAvailable();

        void borrowBook(String ISBN, String BorrowDate, String ReturnDate, int UserID);

        List<borrowDTO> getAllBooksBorrowed(int UID);

        bool returnCheck(String ISBN, String ActualReturnDate, int UID);



        void returnBook(String actualReturnDate, String newActualReturnDate, String ISBN, decimal lateFee);

        List<borrowDTO> getLateFeeRef(String ISBN, int UID, String ActualReturnDate);

        List<borrowDTO> getAllBorrowAdmin();







    }
}
