﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using Model.BookDSTableAdapters;

namespace Controller
{
    public class bookController : IBookController
    {
        public List<bookAllDTO> getAllBooks()
        {
            IBookLogic objBookLogic = new bookLogic();

            List<Book> allBook = objBookLogic.getAllBook();

            if (allBook == null)
            {

                return null;
            }
            else
            {

                List<bookAllDTO> listBookAllDTO = new List<bookAllDTO>();

                foreach (Book refBook in allBook)
                {
                    bookAllDTO objbookAllDTO = new bookAllDTO();
                    objbookAllDTO.ISBN1 = refBook.ISBN1;
                    objbookAllDTO.Author1 = refBook.Author1;
                    objbookAllDTO.BookName1 = refBook.BookName1;
                    objbookAllDTO.Publisher1 = refBook.Publisher1;
                    objbookAllDTO.PublishYear1 = refBook.PublishYear1;
                    objbookAllDTO.Pages1 = refBook.Pages1;
                    objbookAllDTO.AuthorName1 = refBook.AuthorName1;
                    objbookAllDTO.CategoryName1 = refBook.CategoryName1;
                    objbookAllDTO.LanguageName1 = refBook.LanguageName1;
                    objbookAllDTO.Category1 = refBook.Category1;
                    objbookAllDTO.Language1 = refBook.Language1;

                    listBookAllDTO.Add(objbookAllDTO);

                }

                return listBookAllDTO;
            }
        }

        public List<bookAllDTO> getBooksByPublishYear(int publishYear) {

            IBookLogic objBookLogic = new bookLogic();
            List<Book> objBook = objBookLogic.getBookByPublisherYear(publishYear);


            if (objBook == null)
            {
                return null;
            }
            else
            {
                List<bookAllDTO> listBookAllDTO = new List<bookAllDTO>();

                foreach (Book refBook in objBook)
                {
                    bookAllDTO objbookAllDTO = new bookAllDTO();
                    objbookAllDTO.ISBN1 = refBook.ISBN1;
                    objbookAllDTO.Author1 = refBook.Author1;
                    objbookAllDTO.BookName1 = refBook.BookName1;
                    objbookAllDTO.Publisher1 = refBook.Publisher1;
                    objbookAllDTO.PublishYear1 = refBook.PublishYear1;
                    objbookAllDTO.Pages1 = refBook.Pages1;
                    objbookAllDTO.AuthorName1 = refBook.AuthorName1;
                    objbookAllDTO.CategoryName1 = refBook.CategoryName1;
                    objbookAllDTO.LanguageName1 = refBook.LanguageName1;
                    objbookAllDTO.Category1 = refBook.Category1;
                    objbookAllDTO.Language1 = refBook.Language1;

                    listBookAllDTO.Add(objbookAllDTO);

                }

                return listBookAllDTO;



            }
        }

        public List<bookAllDTO> getBooksByAuthor(int Author)
        {

            IBookLogic objBookLogic = new bookLogic();
            List<Book> objBook = objBookLogic.getBookByAuthor(Author);


            if (objBook == null)
            {
                return null;
            }
            else
            {
                List<bookAllDTO> listBookAllDTO = new List<bookAllDTO>();

                foreach (Book refBook in objBook)
                {
                    bookAllDTO objbookAllDTO = new bookAllDTO();
                    objbookAllDTO.ISBN1 = refBook.ISBN1;
                    objbookAllDTO.Author1 = refBook.Author1;
                    objbookAllDTO.BookName1 = refBook.BookName1;
                    objbookAllDTO.Publisher1 = refBook.Publisher1;
                    objbookAllDTO.PublishYear1 = refBook.PublishYear1;
                    objbookAllDTO.Pages1 = refBook.Pages1;
                    objbookAllDTO.AuthorName1 = refBook.AuthorName1;
                    objbookAllDTO.CategoryName1 = refBook.CategoryName1;
                    objbookAllDTO.LanguageName1 = refBook.LanguageName1;
                    objbookAllDTO.Category1 = refBook.Category1;
                    objbookAllDTO.Language1 = refBook.Language1;

                    listBookAllDTO.Add(objbookAllDTO);

                }

                return listBookAllDTO;



            }
        }

        public List<bookAllDTO> getBooksByTitle(String title)
        {

            IBookLogic objBookLogic = new bookLogic();
            List<Book> objBook = objBookLogic.getBookByTitle(title);


            if (objBook == null)
            {
                return null;
            }
            else
            {
                List<bookAllDTO> listBookAllDTO = new List<bookAllDTO>();

                foreach (Book refBook in objBook)
                {
                    bookAllDTO objbookAllDTO = new bookAllDTO();
                    objbookAllDTO.ISBN1 = refBook.ISBN1;
                    objbookAllDTO.Author1 = refBook.Author1;
                    objbookAllDTO.BookName1 = refBook.BookName1;
                    objbookAllDTO.Publisher1 = refBook.Publisher1;
                    objbookAllDTO.PublishYear1 = refBook.PublishYear1;
                    objbookAllDTO.Pages1 = refBook.Pages1;
                    objbookAllDTO.AuthorName1 = refBook.AuthorName1;
                    objbookAllDTO.CategoryName1 = refBook.CategoryName1;
                    objbookAllDTO.LanguageName1 = refBook.LanguageName1;
                    objbookAllDTO.Category1 = refBook.Category1;
                    objbookAllDTO.Language1 = refBook.Language1;

                    listBookAllDTO.Add(objbookAllDTO);

                }

                return listBookAllDTO;



            }
        }

        public void addBookAuthor(String authorName) {
            IBookLogic objBookLogic = new bookLogic();
            objBookLogic.addAuthor(authorName);
        }

        public void addCategory(String catName)
        {
            IBookLogic objBookLogic = new bookLogic();
            objBookLogic.addCategory(catName);
        }

        public void addLanguage(String langName)
        {
            IBookLogic objBookLogic = new bookLogic();
            objBookLogic.addLanguage(langName);
        }

        public void addNewBook(String ISBN, String BookName, int Author, int Category, int Language, int PublishYear, int Pages, String Publisher) {
            IBookLogic objBookLogic = new bookLogic();
            objBookLogic.addNewBook(ISBN, BookName, Author, Category, Language, PublishYear, Pages, Publisher);

        }

        public void updateBook(String ISBN, String BookName, int Author, int Category, int Language, int PublishYear, int Pages, String Publisher, String refISBN)
        {
            IBookLogic objBookLogic = new bookLogic();
            objBookLogic.UpdateBook(ISBN, BookName, Author, Category, Language, PublishYear, Pages, Publisher, refISBN);

        }

        public void deleteBook(String refISBN) {
            IBookLogic objBookLogic = new bookLogic();
            objBookLogic.deleteBook(refISBN);
        }

        public void addBookReserve(String ISBN, int UID, String resDate) {
            IBookLogic objBookLogic = new bookLogic();
            objBookLogic.addReservation(ISBN, UID, resDate);
        }

        public bool validationReserve(String ISBN) {
            IBookLogic objBookLogic = new bookLogic();
            bool tempCheck = objBookLogic.validationReserve(ISBN);

            if (tempCheck == false) {
                return false;
            }
            else
            {
                return true;
            }
        }

        public List<bookAllDTO> getAllBooksAvailable()
        {
            IBookLogic objBookLogic = new bookLogic();

            List<Book> allBook = objBookLogic.getAllBookAvailable();

            if (allBook == null)
            {

                return null;
            }
            else
            {

                List<bookAllDTO> listBookAllDTO = new List<bookAllDTO>();

                foreach (Book refBook in allBook)
                {
                    bookAllDTO objbookAllDTO = new bookAllDTO();
                    objbookAllDTO.ISBN1 = refBook.ISBN1;
                    objbookAllDTO.Author1 = refBook.Author1;
                    objbookAllDTO.BookName1 = refBook.BookName1;
                    objbookAllDTO.Publisher1 = refBook.Publisher1;
                    objbookAllDTO.PublishYear1 = refBook.PublishYear1;
                    objbookAllDTO.Pages1 = refBook.Pages1;
                    objbookAllDTO.AuthorName1 = refBook.AuthorName1;
                    objbookAllDTO.CategoryName1 = refBook.CategoryName1;
                    objbookAllDTO.LanguageName1 = refBook.LanguageName1;
                    objbookAllDTO.Category1 = refBook.Category1;
                    objbookAllDTO.Language1 = refBook.Language1;

                    listBookAllDTO.Add(objbookAllDTO);

                }

                return listBookAllDTO;
            }
        }


        public void borrowBook(String ISBN, String BorrowDate, String ReturnDate, int UserID) {
            IBookLogic objBookLogic = new bookLogic();
            objBookLogic.addBorrowBook(ISBN, BorrowDate, ReturnDate, UserID);
        }

        public List<borrowDTO> getAllBooksBorrowed(int UID) {

            IBookLogic objBookLogic = new bookLogic();
            List<BorrowInstant> allBorrowedBooks = objBookLogic.getAllBorrowedBooks(UID);

            if (allBorrowedBooks == null)
            {

                return null;
            }
            else
            {

                List<borrowDTO> listBorrowedBooks = new List<borrowDTO>();

                foreach (BorrowInstant refBook in allBorrowedBooks)
                {
                    borrowDTO OBDTO = new borrowDTO();

                    OBDTO.ActualReturnDate1 = refBook.ActualReturnDate1;
                    OBDTO.BID1 = refBook.BID1;
                    OBDTO.BorrorwDate1 = refBook.BorrorwDate1;
                    OBDTO.ISBN1 = refBook.ISBN1;
                    OBDTO.LateFee1 = refBook.LateFee1;
                    OBDTO.ReturnDate1 = refBook.ReturnDate1;
                    OBDTO.UID1 = refBook.UID1;

                    listBorrowedBooks.Add(OBDTO);

                }

                return listBorrowedBooks;
            }

        }

        public bool returnCheck(String ISBN, String ActualReturnDate, int UID) {
            IBookLogic objBookLogic = new bookLogic();
            bool tempcheck = objBookLogic.validationReturn(ISBN, ActualReturnDate, UID);
            if (tempcheck == true) {
                return true;
            }
            else
            {
                return false;
            }
        }


        public void returnBook(String actualReturnDate, String newActualReturnDate, String ISBN, decimal lateFee) {
            IBookLogic objBookLogic = new bookLogic();
            objBookLogic.returnBooks(actualReturnDate, newActualReturnDate, ISBN, lateFee);

        }

        public List<borrowDTO> getLateFeeRef(String ISBN,int UID,String ActualReturnDate){

            IBookLogic objBookLogic = new bookLogic();
            List<BorrowInstant> allBorrowedBooks = objBookLogic.getBookLateFee(UID, ISBN, ActualReturnDate);
            if (allBorrowedBooks == null)
            {

                return null;
            }
            else
            {

                List<borrowDTO> listBorrowedBooks = new List<borrowDTO>();

                foreach (BorrowInstant refBook in allBorrowedBooks)
                {
                    borrowDTO OBDTO = new borrowDTO();

                    OBDTO.ActualReturnDate1 = refBook.ActualReturnDate1;
                    OBDTO.BID1 = refBook.BID1;
                    OBDTO.BorrorwDate1 = refBook.BorrorwDate1;
                    OBDTO.ISBN1 = refBook.ISBN1;
                    OBDTO.LateFee1 = refBook.LateFee1;
                    OBDTO.ReturnDate1 = refBook.ReturnDate1;
                    OBDTO.UID1 = refBook.UID1;

                    listBorrowedBooks.Add(OBDTO);

                }

                return listBorrowedBooks;
            }
        }

        public List<borrowDTO> getAllBorrowAdmin()
        {

            IBookLogic objBookLogic = new bookLogic();
            List<BorrowInstant> allBorrowedBooks = objBookLogic.getAllBorrowedBooksAdmin();
            if (allBorrowedBooks == null)
            {

                return null;
            }
            else
            {

                List<borrowDTO> listBorrowedBooks = new List<borrowDTO>();

                foreach (BorrowInstant refBook in allBorrowedBooks)
                {
                    borrowDTO OBDTO = new borrowDTO();

                    OBDTO.ActualReturnDate1 = refBook.ActualReturnDate1;
                    OBDTO.BID1 = refBook.BID1;
                    OBDTO.BorrorwDate1 = refBook.BorrorwDate1;
                    OBDTO.ISBN1 = refBook.ISBN1;
                    OBDTO.LateFee1 = refBook.LateFee1;
                    OBDTO.ReturnDate1 = refBook.ReturnDate1;
                    OBDTO.UID1 = refBook.UID1;

                    listBorrowedBooks.Add(OBDTO);

                }

                return listBorrowedBooks;
            }
        }





    }
}
