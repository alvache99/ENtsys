﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
namespace Controller
{
    public class UserController : IUserController
    {
        public bool accValidation(String Username, String Password)
        {
            
            IUserLogic objUserLogic = new userLogic();

            bool validationCheck = objUserLogic.validationLogin(Username, Password);

            if (validationCheck == true){
                return true;
            }
            else{
                return false;
            }
           

        }
        public void registerAcc(String Username, String Password, int userLevel, String Email) {
            IUserLogic objUserLogic = new userLogic();
            objUserLogic.saveNewUser(Username,Password,userLevel,Email);
        }

        public bool attributeCheck(String username, String email) {
            IUserLogic objUserLogic = new userLogic();
           return objUserLogic.attributeCheckUserLogic(username, email);
        }


        public void deleteAcc(String username) {
            IUserLogic objUserLogic = new userLogic();
            objUserLogic.deleteAccount(username);

        }

        public bool validationChangePw(String firstPw, String secondPw)
        {
            IUserLogic objUserLogic = new userLogic();
            bool valCheck = objUserLogic.validationChangePw(firstPw, secondPw);
            if (valCheck == false) {
                return false;
            }
            else
            {
                return true;
            }
        }

        public void passwordChange(String password, String oriPassword,String username)
        {
            IUserLogic objUserLogic = new userLogic();
            objUserLogic.passwordChange(password, oriPassword, username);
        }

        public userDTO getUserCtrl(String Username, String Password)
        {
            IUserLogic objUserLogic = new userLogic();
            User refUser;

            //I have 0 idea why my refUser is null when i reference it like this
            refUser = objUserLogic.getUser(Username, Password);
            

           

            userDTO objuserDTO = new userDTO();
            objuserDTO.Email1 = refUser.Email1;
            objuserDTO.Password1 = refUser.Password1;
            objuserDTO.UID1 = refUser.UID1;
            objuserDTO.UserLevel = refUser.UserLevel;
            objuserDTO.Username1 = refUser.Username1;

            return objuserDTO;

            
        }
    }
}